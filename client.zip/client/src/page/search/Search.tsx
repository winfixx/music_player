import * as React from 'react'
import styles from './Search.module.scss'
import Navbar from '../../components/navbar/Navbar'

interface SearchProps {
}

const Search: React.FunctionComponent<SearchProps> = (props) => {
  return (
    <div className={styles.container}>
    </div>
  )
}

export default Search
