export interface ChangeInfoHeading {
    avatar: FileList[0] | undefined
    deleteAvatar: boolean
    name?: string | undefined
}
