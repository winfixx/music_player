export interface Genre {
    id: number | null
    name: string
}